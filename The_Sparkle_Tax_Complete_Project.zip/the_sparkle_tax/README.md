# The Sparkle Tax - Diamond Price Prediction

A reproducible undergraduate machine-learning project comparing a median baseline, Ridge Regression, Random Forest Regression, and Histogram Gradient Boosting. It uses **53,940 raw diamond records** (9 predictors + 1 USD price target) from the publicly available `diamonds` dataset distributed with ggplot2/plotnine.

## Quick start

```bash
python -m pip install -r requirements.txt
python run_project.py
```

The script reads `data/diamonds.csv`, saves EDA and results figures into `figures/`, and exports complete experimental metrics and held-out predictions into `outputs/`. Re-run from scratch using seed `42` to reproduce the analysis. The notebook `Sparkle_Tax_Notebook.ipynb` offers a guided, editable introduction and executes the same script.

## Method and safeguards

- Inspect source data; drop exact duplicate rows and 22 records with invalid geometric measurements (`x`, `y`, or `z` <= 0 mm or > 20 mm).
- Retain 53,772 cleaned observations; use 9 predictors (`carat`, `depth`, `table`, `x`, `y`, `z`, `cut`, `color`, and `clarity`).
- Stratified random split into 60% training / 20% validation / 20% untouched test observations, based on target deciles for approximately comparable price coverage. The target bin is **never used as a predictor**.
- Scale numeric variables for Ridge; one-hot encode categorical variables; fit transforms on training data only inside `sklearn.pipeline.Pipeline`.
- Compare two candidate settings per algorithm by validation MAE. Choose winner by validation MAE, refit selected settings on train+validation, and evaluate each on the untouched test only after selection.
- Report MAE, RMSE, median absolute error, and R-squared; plot prediction errors by price and carat ranges and compute held-out permutation importance.

The published figures are reproducible from this script, not hand-entered values. The dataset contains prices without a transaction timestamp, so this is **an interpolative prediction study**, not a future-price forecast or actual jewelry appraisal system.

## Data provenance

`diamonds.csv` is the public `diamonds` dataset from **ggplot2**, provided in Python via `plotnine.data.diamonds` (the analysis file is included here for offline reproducibility). Please credit the upstream project when reusing the data:

- https://plotnine.org/reference/diamonds.html
- https://ggplot2.tidyverse.org/reference/diamonds.html

## Before submitting to class

1. Replace `[Your Name]`, `[Course / Instructor]`, and the public GitHub placeholder in the PDF or regenerated report.
2. Create a **public** GitHub repository and upload this project folder, including `data/diamonds.csv` and the figures, notebook and source.
3. Verify that the GitHub URL is publicly visible in an incognito browser window.
4. Read and personalize the first-person reflection; verify you can explain the model metrics and experimental decisions.

AI assistance: OpenAI ChatGPT was used to help plan the workflow, generate code and draft report text; experimental data were computed by executing the included Python program. Acknowledgement appears in the PDF.
