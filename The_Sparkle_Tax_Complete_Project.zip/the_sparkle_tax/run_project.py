"""THE SPARKLE TAX: reproducible end-to-end diamond price prediction.

Run from the project folder: python run_project.py
Input: data/diamonds.csv (the publicly available ggplot2/plotnine diamonds dataset).
Outputs: figures/*.png, outputs/metrics.csv, outputs/results.json,
         outputs/test_predictions.csv, outputs/validation_search.csv.

The held-out test partition is not used for selecting hyperparameters.
"""
from __future__ import annotations

import json
from pathlib import Path
import warnings

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.inspection import permutation_importance
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, median_absolute_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

SEED = 42
ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "diamonds.csv"
FIG = ROOT / "figures"
OUT = ROOT / "outputs"
NUMERIC = ["carat", "depth", "table", "x", "y", "z"]
CATEGORICAL = ["cut", "color", "clarity"]
FEATURES = NUMERIC + CATEGORICAL
NAVY = "#15243C"
GOLD = "#C39B53"
BLUE = "#316B87"
TEAL = "#348A86"
MUTED = "#657487"
BG = "#FBFAF7"


def plotting_style():
    plt.rcParams.update({
        "figure.facecolor": "white", "axes.facecolor": "white", "axes.edgecolor": "#CFD6DC",
        "axes.labelcolor": NAVY, "text.color": NAVY, "xtick.color": MUTED, "ytick.color": MUTED,
        "font.family": "DejaVu Sans", "font.size": 10, "axes.titlesize": 12,
        "axes.titleweight": "bold", "grid.alpha": 0.18, "savefig.dpi": 170,
    })


def save(fig, name):
    fig.savefig(FIG / name, dpi=175, bbox_inches="tight", pad_inches=0.17)
    plt.close(fig)


def load_clean():
    raw = pd.read_csv(DATA)
    required = set(FEATURES + ["price"])
    if not required.issubset(raw.columns):
        raise ValueError(f"Dataset missing columns: {required - set(raw.columns)}")
    raw_n = len(raw)
    null_cells = int(raw.isna().sum().sum())
    duplicate_rows = int(raw.duplicated().sum())
    unique = raw.drop_duplicates().copy()
    # A physical length/width/depth cannot be zero or negative. Values above 20 mm
    # are treated as suspect here because recorded stones are otherwise < 11 mm.
    bad_geom = ((unique[["x", "y", "z"]] <= 0) |
                (unique[["x", "y", "z"]] > 20)).any(axis=1)
    bad_n = int(bad_geom.sum())
    clean = unique.loc[~bad_geom].copy().reset_index(drop=True)
    assert len(clean) >= 10000 and len(FEATURES) >= 5
    assert clean[FEATURES + ["price"]].isna().sum().sum() == 0
    audit = {"raw_rows": raw_n, "raw_columns": len(raw.columns),
             "raw_missing_cells": null_cells, "exact_duplicates_removed": duplicate_rows,
             "invalid_geometry_rows_removed": bad_n, "retained_rows": len(clean),
             "predictor_count": len(FEATURES),
             "price_mean": float(clean.price.mean()),
             "price_median": float(clean.price.median()),
             "price_std": float(clean.price.std()),
             "min_price": int(clean.price.min()), "max_price": int(clean.price.max()),
             "carat_price_pearson": float(clean[["carat", "price"]].corr().iloc[0, 1])}
    return clean, audit


def get_splits(df):
    # Stratify on 10 price-quantile bins to preserve broad price mix in each
    # randomly held-out set. Stratification uses target bins only for splitting,
    # NEVER as a model predictor. The dataset has no timestamps for a time split.
    strata = pd.qcut(df["price"], q=10, labels=False, duplicates="drop")
    idx_trainval, idx_test = train_test_split(
        np.arange(len(df)), test_size=0.20, random_state=SEED, stratify=strata)
    idx_train, idx_val = train_test_split(
        idx_trainval, test_size=0.25, random_state=SEED+1,
        stratify=strata.iloc[idx_trainval])
    return {"train": df.iloc[idx_train], "validation": df.iloc[idx_val],
            "test": df.iloc[idx_test], "train_validation": df.iloc[idx_trainval]}


def preprocessor(model_name):
    if model_name == "Ridge Regression":
        # Scaling is important for ridge's L2 regularization, since numeric
        # predictor scales vary widely; encode quality labels without ordering.
        numeric = StandardScaler()
    else:
        # Trees are insensitive to rescaling numeric columns.
        numeric = "passthrough"
    return ColumnTransformer(
        [("num", numeric, NUMERIC),
         ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), CATEGORICAL)],
        remainder="drop", sparse_threshold=0)


def get_pipeline(name, params):
    if name == "Ridge Regression":
        estimator = Ridge(alpha=params["alpha"])
    elif name == "Random Forest":
        estimator = RandomForestRegressor(
            n_estimators=140, min_samples_leaf=params["min_samples_leaf"],
            max_features=0.85, n_jobs=-1, random_state=SEED)
    elif name == "Gradient Boosting":
        estimator = HistGradientBoostingRegressor(
            max_iter=230, learning_rate=0.075, max_leaf_nodes=params["max_leaf_nodes"],
            l2_regularization=0.2, random_state=SEED)
    else:
        raise KeyError(name)
    return Pipeline([("prep", preprocessor(name)), ("model", estimator)])


def model_metrics(y, pred):
    return {"mae": float(mean_absolute_error(y, pred)),
            "rmse": float(np.sqrt(mean_squared_error(y, pred))),
            "median_ae": float(median_absolute_error(y, pred)),
            "r2": float(r2_score(y, pred))}


def draw_eda(df):
    sample = df.sample(n=min(5000, len(df)), random_state=SEED)
    fig, axes = plt.subplots(2, 2, figsize=(11.7, 7.9), constrained_layout=True)
    axs = axes.ravel()
    axs[0].hist(df.price, bins=54, color=BLUE, alpha=.88, edgecolor="white", linewidth=.3)
    axs[0].axvline(df.price.median(), color=GOLD, linewidth=2.4, label="Median")
    axs[0].set(title="Price spans hundreds to five figures", xlabel="Listed price (USD)", ylabel="Diamond count")
    axs[0].legend(frameon=False)
    axs[1].scatter(sample.carat, sample.price, s=7, color=BLUE, alpha=.22, rasterized=True)
    axs[1].set(title="Carat matters - but it is not the whole story", xlabel="Carat weight", ylabel="Listed price (USD)")
    ordered = ["Fair", "Good", "Very Good", "Premium", "Ideal"]
    cutmed = df.groupby("cut", observed=True)[["price", "carat"]].median().reindex(ordered)
    axs[2].bar(ordered, cutmed.price, color=[MUTED, BLUE, TEAL, GOLD, NAVY], alpha=.90)
    axs[2].set(title="Raw median price by cut (confounded by weight)", ylabel="Median price (USD)")
    axs[2].tick_params(axis="x", labelrotation=15)
    clarity = ["I1", "SI2", "SI1", "VS2", "VS1", "VVS2", "VVS1", "IF"]
    cont = pd.crosstab(df["cut"], df["clarity"]).reindex(index=ordered, columns=clarity)
    image = axs[3].imshow(cont, cmap="YlGnBu", aspect="auto")
    axs[3].set(title="Data coverage: cut x clarity", xlabel="Clarity grade", ylabel="Cut grade")
    axs[3].set_xticks(range(len(clarity)), labels=clarity, rotation=30)
    axs[3].set_yticks(range(len(ordered)), labels=ordered)
    fig.colorbar(image, ax=axs[3], shrink=.82, label="Records")
    save(fig, "01_data_exploration.png")
    fig, ax = plt.subplots(figsize=(9.2, 4.8))
    b = pd.cut(df.carat, [0,.5,1,1.5,2,6], labels=["0-0.5", "0.5-1", "1-1.5", "1.5-2", "2+"])
    buckets = df.groupby(b, observed=True).price.agg(["median", "count"])
    ax.bar(buckets.index.astype(str), buckets["median"], color=[BLUE, BLUE, TEAL, TEAL, GOLD])
    ax.set(title="The carat effect: median listed price rises nonlinearly", xlabel="Carat interval", ylabel="Median listed price (USD)")
    for i, (_, r) in enumerate(buckets.iterrows()):
        ax.text(i, r["median"] + 140, f'n={int(r["count"]):,}', ha="center", fontsize=8, color=MUTED)
    ax.set_ylim(0,buckets["median"].max()*1.18)
    save(fig,"02_carat_bands.png")
    return {"cut_median_price": {str(k): float(v) for k, v in cutmed.price.items()},
            "cut_median_carat": {str(k): float(v) for k, v in cutmed.carat.items()},
            "carat_band_count": {str(k): int(v) for k, v in buckets["count"].items()},
            "carat_band_median": {str(k): float(v) for k, v in buckets["median"].items()}}


def evaluate_and_draw(splits, audit, eda):
    models = {
        "Ridge Regression": [{"alpha": .1}, {"alpha": 100.0}],
        "Random Forest": [{"min_samples_leaf": 1}, {"min_samples_leaf": 3}],
        "Gradient Boosting": [{"max_leaf_nodes": 15}, {"max_leaf_nodes": 31}],
    }
    Xt, yt = splits["train"][FEATURES], splits["train"].price
    Xv, yv = splits["validation"][FEATURES], splits["validation"].price
    Xtv, ytv = splits["train_validation"][FEATURES], splits["train_validation"].price
    Xh, yh = splits["test"][FEATURES], splits["test"].price

    baseline = DummyRegressor(strategy="median")
    baseline.fit(Xt, yt)
    validation_rows = [{"model": "Median Baseline", "params": "constant training median", **model_metrics(yv, baseline.predict(Xv))}]
    best_val = {}
    print("Tuning only against validation set (test remains sealed):", flush=True)
    for name, candidates in models.items():
        scored = []
        for params in candidates:
            estimator = get_pipeline(name, params)
            estimator.fit(Xt, yt)
            m = model_metrics(yv, estimator.predict(Xv))
            validation_rows.append({"model": name, "params": json.dumps(params, sort_keys=True), **m})
            scored.append((m["mae"],params))
            print(f"  {name}: {params} - validation MAE ${m['mae']:,.2f}", flush=True)
        _, chosen = min(scored, key=lambda t: t[0])
        best_val[name] = chosen

    # Choice of best configuration is frozen before ANY test scoring.
    val_df = pd.DataFrame(validation_rows)
    val_df.to_csv(OUT / "validation_search.csv", index=False)
    chosen_val = {"Median Baseline": validation_rows[0]}
    for name, params in best_val.items():
        target = json.dumps(params, sort_keys=True)
        chosen_val[name] = val_df[(val_df.model==name)&(val_df.params==target)].iloc[0].to_dict()
    winner = min(best_val.keys(), key=lambda name: chosen_val[name]["mae"])

    results = []
    final_models = {}
    base_final = DummyRegressor(strategy="median").fit(Xtv, ytv)
    results.append({"model": "Median Baseline", **model_metrics(yh,base_final.predict(Xh))})
    for name,params in best_val.items():
        m = get_pipeline(name,params).fit(Xtv,ytv)
        final_models[name] = m
        results.append({"model":name, **model_metrics(yh,m.predict(Xh))})
    results_df = pd.DataFrame(results)
    results_df.to_csv(OUT / "metrics.csv",index=False)
    print("\nHeld-out test performance:\n",results_df.round(3).to_string(index=False),flush=True)
    pred = np.clip(final_models[winner].predict(Xh),0,None)
    # No clipping usually necessary; use the actual model predictions for the
    # report's metric table (pred here is only used for the diagnostic figures).
    yarr = yh.to_numpy()
    test_pred = splits["test"].copy()
    test_pred["prediction"] = pred
    test_pred["signed_error"] = pred - yarr
    test_pred["absolute_error"] = np.abs(pred-yarr)
    test_pred.to_csv(OUT / "test_predictions.csv",index=False)

    # A deliberately limited predictor sanity check: same boosting algorithm,
    # but only carat, highlighting how much quality information adds.
    carat_model = HistGradientBoostingRegressor(
        max_iter=230, learning_rate=.075, max_leaf_nodes=15,
        l2_regularization=.2,random_state=SEED)
    carat_model.fit(Xtv[["carat"]],ytv)
    carat_only = model_metrics(yh,carat_model.predict(Xh[["carat"]]))

    price_bins=[0,1000,3000,6000,10000,float("inf")]
    price_labels=["$0-1k","$1-3k","$3-6k","$6-10k","$10k+"]
    price_band = pd.cut(yh,bins=price_bins,labels=price_labels)
    err_band = test_pred.groupby(price_band,observed=True).absolute_error.agg(["mean","count"])
    carat_labels=["0-0.5","0.5-1","1-1.5","1.5-2","2+"]
    carat_band=pd.cut(Xh.carat,bins=[0,.5,1,1.5,2,6],labels=carat_labels)
    err_carat=test_pred.groupby(carat_band,observed=True).absolute_error.agg(["mean","count"])
    err_cut=test_pred.groupby(Xh.cut,observed=True).absolute_error.agg(["mean","count"])

    rng=np.random.default_rng(SEED)
    sel=rng.choice(len(yarr),size=min(3000,len(yarr)),replace=False)
    fig, axes=plt.subplots(1,2,figsize=(11.4,4.5),constrained_layout=True)
    names=list(results_df.model)
    bars=axes[0].barh(names[::-1],results_df.mae.to_numpy()[::-1],color=[GOLD,TEAL,BLUE,MUTED][::-1])
    axes[0].set(title="Test-set prediction error (lower is better)",xlabel="Mean absolute error (USD)")
    for bar in bars:
        axes[0].text(bar.get_width()+30,bar.get_y()+bar.get_height()/2,f"${bar.get_width():,.0f}",va="center",fontsize=9)
    axes[0].set_xlim(0,results_df.mae.max()*1.20)
    bars=axes[1].barh(names[::-1],results_df.r2.to_numpy()[::-1],color=[GOLD,TEAL,BLUE,MUTED][::-1])
    axes[1].set(title="Explained price variance (higher is better)",xlabel="Test R-squared",xlim=(min(0,results_df.r2.min()-.1),1.03))
    for b in bars:
        axes[1].text(b.get_width()+0.015,b.get_y()+b.get_height()/2,f"{b.get_width():.3f}",va="center",fontsize=9)
    save(fig,"03_model_comparison.png")

    fig,axes=plt.subplots(1,2,figsize=(11.4,4.7),constrained_layout=True)
    axes[0].scatter(yarr[sel],pred[sel],s=8,alpha=.22,c=BLUE,rasterized=True)
    axes[0].plot([0,19000],[0,19000],color=GOLD,ls="--",lw=2)
    axes[0].set(xlabel="Actual listed price (USD)",ylabel="Predicted price (USD)",title=f"{winner}: actual vs. predicted",xlim=(0,19000),ylim=(0,19000))
    axes[1].scatter(yarr[sel],(pred-yarr)[sel],s=8,alpha=.22,c=TEAL,rasterized=True)
    axes[1].axhline(0,ls="--",color=GOLD,lw=2)
    axes[1].set(xlabel="Actual listed price (USD)",ylabel="Prediction minus actual (USD)",title="Residuals reveal hard-to-price segments")
    save(fig,"04_predictions_and_residuals.png")

    fig,axes=plt.subplots(1,2,figsize=(11.4,4.1),constrained_layout=True)
    axes[0].bar(err_band.index.astype(str),err_band["mean"],color=[BLUE,BLUE,TEAL,TEAL,GOLD])
    axes[0].set(title="Absolute error rises with price tier",ylabel="Mean absolute error (USD)",xlabel="Actual price group")
    axes[0].tick_params(axis="x",rotation=15)
    axes[1].bar(err_carat.index.astype(str),err_carat["mean"],color=[BLUE,BLUE,TEAL,TEAL,GOLD])
    axes[1].set(title="Larger diamonds are harder to appraise",ylabel="Mean absolute error (USD)",xlabel="Carat group")
    save(fig,"05_segment_errors.png")

    # Model-agnostic permutation importance on held-out data. 2,000 rows and
    # 3 shuffles cap runtime and preserve a meaningful repeated estimate.
    subset=Xh.sample(n=min(2000,len(Xh)),random_state=SEED)
    subset_y=yh.loc[subset.index]
    importance = permutation_importance(final_models[winner],subset,subset_y,
                                        n_repeats=3,scoring="neg_mean_absolute_error",
                                        random_state=SEED,n_jobs=1)
    imp_df=pd.DataFrame({"feature":FEATURES,"increase_in_mae":importance.importances_mean,
                         "sd":importance.importances_std}).sort_values("increase_in_mae",ascending=False)
    imp_df.to_csv(OUT/"permutation_importance.csv",index=False)
    fig,ax=plt.subplots(figsize=(9.5,4.7))
    rev=imp_df.iloc[::-1]
    ax.barh(rev.feature,rev.increase_in_mae,xerr=rev.sd,color=[GOLD if x=="carat" else BLUE for x in rev.feature],
            error_kw={"elinewidth":1,"capsize":2,"ecolor":MUTED})
    ax.axvline(0,c=MUTED,lw=.8)
    ax.set(title="Feature importance - the cost of shuffling a predictor",xlabel="Increase in MAE (USD); greater means more model reliance")
    save(fig,"06_permutation_importance.png")

    metrics = {r["model"]: {k:float(r[k]) for k in ["mae","rmse","median_ae","r2"]} for r in results}
    result={"dataset":audit, "eda":eda,
            "split_counts":{k:len(v) for k,v in splits.items()},
            "seed":SEED,"validation_results":{m:{"mae":float(s["mae"]),"r2":float(s["r2"])} for m,s in chosen_val.items()},
            "selected_parameters":best_val,"validation_winner":winner,
            "test_metrics":metrics,"carat_only_boosting_test":carat_only,
            "within_500_fraction":float((np.abs(pred-yarr)<=500).mean()),
            "within_1000_fraction":float((np.abs(pred-yarr)<=1000).mean()),
            "test_p90_absolute_error":float(np.quantile(np.abs(pred-yarr),.9)),
            "test_signed_error_mean":float(np.mean(pred-yarr)),
            "price_group_mae":{str(k):round(float(v),2) for k,v in err_band["mean"].items()},
            "price_group_n":{str(k):int(v) for k,v in err_band["count"].items()},
            "carat_group_mae":{str(k):round(float(v),2) for k,v in err_carat["mean"].items()},
            "carat_group_n":{str(k):int(v) for k,v in err_carat["count"].items()},
            "cut_group_mae":{str(k):round(float(v),2) for k,v in err_cut["mean"].items()},
            "permutation_importance":{str(r.feature):float(r.increase_in_mae) for r in imp_df.itertuples()}}
    (OUT/"results.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    return result


def main():
    FIG.mkdir(parents=True,exist_ok=True)
    OUT.mkdir(parents=True,exist_ok=True)
    plotting_style()
    df,audit=load_clean()
    eda=draw_eda(df)
    splits=get_splits(df)
    r=evaluate_and_draw(splits,audit,eda)
    print("\nValidated results saved to:", OUT, "\nFigures saved to:", FIG,flush=True)
    return r


if __name__=="__main__":
    main()
