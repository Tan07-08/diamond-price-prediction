"""Generate the polished ML final project report from computed experiment outputs.

Examples:
    python make_report.py
    python make_report.py --name 'Jane Doe' --course 'ITCS Machine Learning | Prof. Smith' \
         --github 'https://github.com/your-handle/the-sparkle-tax'

Figures and results must first be produced by `python run_project.py`.
"""
from __future__ import annotations

import argparse
import json
from datetime import date
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, Image,
    HRFlowable, KeepTogether, CondPageBreak
)

ROOT = Path(__file__).resolve().parent
FIG = ROOT / "figures"
OUT = ROOT / "outputs"
NAVY = colors.HexColor("#15243C")
MID = colors.HexColor("#316B87")
TEAL = colors.HexColor("#348A86")
GOLD = colors.HexColor("#C39B53")
GRAY = colors.HexColor("#657487")
OFF = colors.HexColor("#F7F9FA")
LINE = colors.HexColor("#DCE3E8")
WHITE = colors.white
W, H = letter
BODYW = W - 2 * 0.76 * inch

font_files = {
    "Lato": "/usr/share/fonts/truetype/lato/Lato-Regular.ttf",
    "Lato-Bold": "/usr/share/fonts/truetype/lato/Lato-Bold.ttf",
    "Lato-Italic": "/usr/share/fonts/truetype/lato/Lato-Italic.ttf",
    "Lato-Heavy": "/usr/share/fonts/truetype/lato/Lato-Heavy.ttf",
    "DejaVuSerif": "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf",
    "DejaVuSerif-Bold": "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf",
}
for k, f in font_files.items():
    pdfmetrics.registerFont(TTFont(k, f))
pdfmetrics.registerFontFamily("Lato",normal="Lato",bold="Lato-Bold",italic="Lato-Italic",boldItalic="Lato-Bold")

styles = {}
styles["body"] = ParagraphStyle(
    "BodyX", fontName="Lato", fontSize=9.65, leading=14.9,
    textColor=NAVY, spaceAfter=8.0)
styles["tiny"] = ParagraphStyle("Tiny",parent=styles["body"],fontSize=7.4, leading=10, spaceAfter=4)
styles["small"] = ParagraphStyle("Small",parent=styles["body"],fontSize=8.65, leading=12.5, spaceAfter=6)
styles["abstract"] = ParagraphStyle("Abstract",parent=styles["body"],fontSize=10.5,leading=17.2,spaceAfter=10)
styles["h1"] = ParagraphStyle("H1",fontName="DejaVuSerif-Bold",fontSize=18.1,leading=23.4,textColor=NAVY,spaceBefore=8,spaceAfter=13)
styles["h2"] = ParagraphStyle("H2",fontName="Lato-Bold",fontSize=12.15,leading=16.5,textColor=MID,spaceBefore=11,spaceAfter=7)
styles["h3"] = ParagraphStyle("H3",fontName="Lato-Bold",fontSize=10.05,leading=13.7,textColor=NAVY,spaceBefore=8,spaceAfter=5)
styles["eyebrow"] = ParagraphStyle("Eyebrow",fontName="Lato-Bold",fontSize=8.1,leading=11,textColor=TEAL,spaceBefore=2,spaceAfter=9)
styles["caption"] = ParagraphStyle("Caption",fontName="Lato-Italic",fontSize=8.25,leading=11.8,textColor=GRAY,spaceAfter=10,alignment=TA_LEFT)
styles["table"] = ParagraphStyle("Cell",fontName="Lato",fontSize=8.45,leading=11.7,textColor=NAVY)
styles["tablehead"] = ParagraphStyle("CellHead",fontName="Lato-Bold",fontSize=8.25,leading=11.6,textColor=WHITE)
styles["ref"] = ParagraphStyle("Ref",fontName="Lato",fontSize=8.65,leading=13.5,textColor=NAVY,leftIndent=15,firstLineIndent=-15,spaceAfter=8)
styles["quote"] = ParagraphStyle("Quote",fontName="Lato-Italic",fontSize=10.4,leading=16,textColor=NAVY,spaceAfter=0)


def P(text, kind="body"):
    return Paragraph(text, styles[kind])


def money(v, digs=0):
    return "${:,.{}f}".format(v, digs)


def q(v, digits=2):
    return f"{v:,.{digits}f}"


def line():
    return HRFlowable(width="100%", thickness=.65, color=LINE, spaceBefore=5,spaceAfter=11)


def heading(num, title, kicker=None):
    if kicker:
        story.append(P(kicker.upper(), "eyebrow"))
    story.append(P(f"{num}  {title}", "h1"))
    story.append(line())


def sub(title):
    story.append(P(title,"h2"))


def paragraph(txt):
    story.append(P(txt))


def callout(txt):
    cell = Table([[P(txt,"quote")]],colWidths=[BODYW-22])
    cell.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1),colors.HexColor("#F4F6F7")),
        ("LINEBEFORE",(0,0),(0,-1),3.2,GOLD),
        ("LEFTPADDING",(0,0),(-1,-1),12),("RIGHTPADDING",(0,0),(-1,-1),13),
        ("TOPPADDING",(0,0),(-1,-1),10),("BOTTOMPADDING",(0,0),(-1,-1),10),
    ]))
    story.append(cell)
    story.append(Spacer(1,9))


def bullet(txt):
    para=P(f'<font color="#C39B53"><b>•</b></font>  {txt}',"body")
    story.append(para)


def tbl(rows, widths, alignment="LEFT", fontstyle="table", grid=False):
    items=[]
    for i,row in enumerate(rows):
        kind="tablehead" if i==0 else fontstyle
        items.append([P(escape(str(cell)).replace("&lt;b&gt;","<b>").replace("&lt;/b&gt;","</b>"),kind) for cell in row])
    t=Table(items,colWidths=widths,repeatRows=1,hAlign=alignment)
    cmds=[
        ("BACKGROUND",(0,0),(-1,0),NAVY),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[WHITE,OFF]),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
        ("LEFTPADDING",(0,0),(-1,-1),8),
        ("RIGHTPADDING",(0,0),(-1,-1),8),
        ("TOPPADDING",(0,0),(-1,0),8),
        ("BOTTOMPADDING",(0,0),(-1,0),8),
        ("TOPPADDING",(0,1),(-1,-1),6),
        ("BOTTOMPADDING",(0,1),(-1,-1),6),
        ("LINEBELOW",(0,-1),(-1,-1),.7,LINE),
    ]
    if grid:
        cmds.append(("INNERGRID",(0,1),(-1,-1),.25,LINE))
    t.setStyle(TableStyle(cmds))
    story.append(t)
    story.append(Spacer(1,12))


def figure(file, label, width=BODYW):
    from PIL import Image as PILImage
    imgpath=FIG/file
    with PILImage.open(imgpath) as im:
        iw,ih=im.size
    height=width*ih/iw
    story.append(Image(str(imgpath),width=width,height=height,hAlign="CENTER"))
    story.append(P(label,"caption"))


def newpage():
    story.append(PageBreak())


def cover_page(canvas, doc, name, course, reportdate):
    canvas.saveState()
    canvas.setFillColor(NAVY)
    canvas.rect(0,0,W,H,fill=1,stroke=0)
    # Editorial diagonal tint stripes
    canvas.setStrokeColor(colors.HexColor("#284056"))
    canvas.setLineWidth(0.7)
    for i in range(-7,11):
        xx=i*58
        p=canvas.beginPath();p.moveTo(xx,0);p.lineTo(xx+320,H)
        canvas.drawPath(p,stroke=1,fill=0)
    canvas.setFillColor(GOLD)
    canvas.roundRect(53,706,7,7,3,stroke=0,fill=1)
    canvas.setFont("Lato-Bold",10)
    canvas.drawString(68,706,"AN ORIGINAL MACHINE LEARNING INVESTIGATION")
    canvas.setFillColor(colors.HexColor("#E9ECF2"))
    canvas.setFont("Lato-Heavy",51)
    canvas.drawString(54,630,"THE")
    canvas.drawString(54,566,"SPARKLE")
    canvas.setFillColor(GOLD)
    canvas.drawString(54,502,"TAX")
    # Small gemstone: faceted outline on the right
    from reportlab.lib.colors import HexColor
    canvas.setStrokeColor(GOLD)
    canvas.setLineWidth(1.6)
    A=(397,629);B=(482,629);C=(546,569);D=(439,438);E=(330,569)
    edges=[(A,B),(B,C),(C,D),(D,E),(E,A),(E,C),(A,D),(B,D),(A,(359,569)),(B,(518,569))]
    for (x1,y1),(x2,y2) in edges:
        canvas.line(x1,y1,x2,y2)
    canvas.setFillColor(colors.HexColor("#EEE1C3"))
    canvas.setFont("Lato-Bold",17)
    canvas.drawString(56,408,"Can machine learning predict")
    canvas.drawString(56,385,"what a diamond should cost?")
    canvas.setStrokeColor(GOLD);canvas.setLineWidth(1.8)
    canvas.line(55,365,550,365)
    canvas.setFillColor(colors.HexColor("#E8EBEF"))
    canvas.setFont("Lato",11)
    canvas.drawString(56,340,"From carat weight and clarity to real predictions, real mistakes,")
    canvas.drawString(56,324,"and the uncomfortable question: what does 'accurate' mean?")
    # 4 horizontally aligned stat tiles
    tiles=[("53,940","RAW RECORDS"),("9","PREDICTORS"),("3 + 1","ML MODELS + BASELINE"),("10,755","TEST RECORDS")]
    boxW=119;gap=8;start=56
    for i,(big,lbl) in enumerate(tiles):
        x=start+i*(boxW+gap)
        canvas.setFillColor(colors.HexColor("#253B53"))
        canvas.roundRect(x,206,boxW,87,8,stroke=0,fill=1)
        canvas.setFillColor(GOLD);canvas.setFont("Lato-Heavy",20)
        canvas.drawCentredString(x+boxW/2,254,big)
        canvas.setFillColor(WHITE);canvas.setFont("Lato-Bold",7.1)
        canvas.drawCentredString(x+boxW/2,228,lbl)
    canvas.setStrokeColor(colors.HexColor("#3B5166"));canvas.line(55,166,554,166)
    canvas.setFillColor(WHITE);canvas.setFont("Lato-Bold",12)
    canvas.drawString(56,142,name)
    canvas.setFont("Lato",9.8);canvas.setFillColor(colors.HexColor("#D7DEE5"))
    canvas.drawString(56,121,course)
    canvas.drawString(56,101,"Final Project Report  |  " + reportdate)
    canvas.setFillColor(GOLD);canvas.setFont("Lato-Italic",10)
    canvas.drawString(55,55,"Diamonds may be forever. A model's first draft shouldn't be.")
    canvas.restoreState()


def normal_page(canvas,doc):
    canvas.saveState()
    canvas.setStrokeColor(LINE);canvas.setLineWidth(.7)
    canvas.line(0.76*inch,H-.56*inch,W-.76*inch,H-.56*inch)
    canvas.setFont("Lato-Bold",7.8);canvas.setFillColor(MID)
    canvas.drawString(.76*inch,H-.46*inch,"THE SPARKLE TAX")
    canvas.setFont("Lato",7.7);canvas.setFillColor(GRAY)
    canvas.drawRightString(W-.76*inch,H-.46*inch,"MACHINE LEARNING  /  FINAL REPORT")
    canvas.line(.76*inch,.54*inch,W-.76*inch,.54*inch)
    canvas.setFont("Lato",7.8)
    canvas.drawString(.76*inch,.38*inch,"Reproducible study  |  ggplot2 diamonds  |  2026")
    canvas.drawRightString(W-.76*inch,.38*inch,f"{doc.page:02d}")
    canvas.restoreState()


def build(name, course, github, path):
    global story
    r=json.loads((OUT/"results.json").read_text(encoding="utf-8"))
    d=r["dataset"]; eda=r["eda"]; metrics=r["test_metrics"]
    win=r["validation_winner"]; vm=r["validation_results"]
    rf=metrics["Random Forest"]; gb=metrics["Gradient Boosting"]
    base=metrics["Median Baseline"]
    gain=(1-rf["mae"]/base["mae"])*100
    clean=d["retained_rows"]
    doc=SimpleDocTemplate(str(path),pagesize=letter,leftMargin=.76*inch,rightMargin=.76*inch,
                          topMargin=.82*inch,bottomMargin=.72*inch,
                          title="The Sparkle Tax | Diamond Price Prediction with Machine Learning",
                          author=name,subject="Reproducible machine learning final project")
    story=[]
    # 01 - cover. All cover details are rendered in onFirstPage.
    story.append(Spacer(1,8.0*inch))
    newpage()

    # 02 - executive summary
    story.append(P("EXECUTIVE SUMMARY", "eyebrow"))
    story.append(P("An expensive little question","h1"))
    story.append(line())
    story.append(P("Why do two similarly sized diamonds carry very different price tags? My project turns that everyday question into a supervised learning problem: predict the listed price, in US dollars, of a diamond from its size, proportions, cut, color, and clarity. I use the public <i>diamonds</i> data distributed through ggplot2/plotnine, containing 53,940 records and nine predictors (\"Diamonds,\" <i>plotnine</i>).", "abstract"))
    story.append(P(f"After removing {d['exact_duplicates_removed']:,} exact duplicate records and {d['invalid_geometry_rows_removed']:,} records with invalid dimensions, {clean:,} remain. The analysis compares a median baseline, Ridge Regression, Random Forest, and Histogram Gradient Boosting. Two settings per learning algorithm are selected by validation mean absolute error (MAE); a separate {r['split_counts']['test']:,}-row test set is used for the final reported assessment.","abstract"))
    story.append(P(f"<b>Main result.</b> Random Forest had the lowest held-out MAE at <b>{money(rf['mae'],2)}</b>, with R-squared <b>{rf['r2']:.3f}</b>. That is a <b>{gain:.1f}%</b> improvement in MAE compared with predicting the median price for every diamond. Gradient Boosting achieved a slightly better RMSE, highlighting why choosing the evaluation metric matters. Errors are substantially larger in dollar terms for high-priced stones; performance on this historical dataset is not a current market appraisal.","abstract"))
    story.append(Spacer(1,10))
    tbl([
        ["STUDY AT A GLANCE","VALUE","WHAT IT MEANS"],
        ["Problem type","Regression","Predict continuous price (USD)"],
        ["Dataset size",f"{d['raw_rows']:,} raw / {clean:,} retained","More than 5x the minimum sample count"],
        ["Predictors","9","Six numeric + three categorical"],
        ["Split", "60% / 20% / 20%", "Training / validation / untouched test"],
        ["Primary metric", "MAE", "Average absolute dollar error"],
        ["Winning model", "Random Forest", "Selected using validation, not test score"],
    ],[1.45*inch,1.35*inch,BODYW-2.8*inch])
    callout("The key lesson: a strong test score is only the beginning. Understanding <b>when</b> a model fails matters just as much as celebrating when it wins.")
    paragraph("<b>Reading guide:</b> Sections 1-2 motivate and explore the data; Sections 3-5 document cleaning, models, and experimental safeguards; Section 6 analyzes results; Section 7 reflects on learning and limitations. MLA citations, acknowledgements, and code access follow.")
    newpage()

    # 03 - introduction
    heading("01", "Introduction", "the problem")
    sub("1.1 Motivation: price tags without magic")
    paragraph("Diamond pricing looks straightforward until you compare actual stones. Carat weight measures mass, but cut, color, clarity, and physical proportions also influence the observed listed price. Humans can learn rough rules (\"bigger usually costs more\"), yet those rules struggle with nonlinear relationships and combinations of quality attributes. A regression model provides a testable way to learn those patterns from examples rather than guessing from one feature alone (\"Diamonds,\" <i>ggplot2</i>).")
    paragraph("This is a useful machine learning problem because a single number, price, summarizes a complicated interaction of numerical and categorical information. It also illustrates a classic trap in data analysis: a group that appears cheaper in a summary table may simply contain smaller stones. My goal is not to replace a professional appraiser. It is to assess how reliably common algorithms can reconstruct prices in this dataset and identify the circumstances in which they are least dependable.")
    sub("1.2 Research questions")
    bullet("<b>RQ1:</b> How much better are trained models than predicting the same median price for every diamond?")
    bullet("<b>RQ2:</b> Does a nonlinear ensemble substantially outperform a regularized linear model?")
    bullet("<b>RQ3:</b> Which features does the selected model rely on, and which price or size segments produce the largest errors?")
    bullet("<b>RQ4:</b> What changes when the model sees only carat instead of the full quality profile?")
    sub("1.3 Hypotheses and contribution")
    paragraph("I expected ensemble models to outperform Ridge because pricing is unlikely to increase in one constant, linear step with carat. I also expected expensive and very large diamonds to be harder to predict because they are rarer and their prices spread out more widely. The contribution of this project is a transparent, end-to-end comparison with an intentionally untouched test set, a feature-ablation experiment, and segment-level diagnostics rather than a single impressive accuracy number (Pedregosa et al.).")
    callout("An early suspicion: if a model needs only a spreadsheet column labeled <i>carat</i>, it probably has not learned the whole business of diamonds.")
    sub("1.4 Scope")
    paragraph("The data lack reliable transaction dates, store identities, appraiser certificates, geographic markets, and 2026 market information. Thus, predictions estimate historical listed prices in this teaching dataset. They should not be used for purchasing decisions, valuation of an individual item, or claims about what caused a price change.")
    newpage()

    # 04 - data dictionary
    heading("02","Data and exploratory analysis", "where the numbers come from")
    sub("2.1 Dataset source, target, and data dictionary")
    paragraph("The <i>diamonds</i> dataset, originally made available with the R ggplot2 ecosystem and exposed in Python through plotnine, comprises 53,940 rows and 10 columns: nine candidate predictors and one target. The values represent prices and attributes of round-cut diamonds. The analysis uses a local CSV copy of this public dataset to ensure it can run offline (\"Diamonds,\" <i>plotnine</i>; \"Diamonds,\" <i>ggplot2</i>).")
    rows=[["VARIABLE","DATA TYPE","MEANING / ANALYTICAL ROLE"],
          ["price","Integer - target","Listed price in US dollars"],
          ["carat","Numeric","Diamond weight; strongest expected size signal"],
          ["cut","Categorical","Fair, Good, Very Good, Premium, Ideal"],
          ["color","Categorical","Color categories D (best) to J (worst)"],
          ["clarity","Categorical","Clarity categories I1 through IF"],
          ["depth","Numeric","Total depth percentage"],
          ["table","Numeric","Top facet width as percentage"],
          ["x / y / z","Numeric (3)","Length / width / depth in millimeters"]]
    tbl(rows,[1.12*inch,1.4*inch,BODYW-2.52*inch])
    sub("2.2 Basic descriptive statistics")
    tbl([
        ["MEASURE","VALUE","READING"],
        ["Raw observations",f"{d['raw_rows']:,}","Meets 10,000+ requirement"],
        ["Input variables",f"{d['predictor_count']}","Meets 5+ feature requirement"],
        ["Median price",money(d["price_median"]),"More representative than mean for skew"],
        ["Mean price",money(d["price_mean"],2),"Exceeds median: right-skewed distribution"],
        ["Observed price range",f'{money(d["min_price"])} to {money(d["max_price"])}',"Very different price scales"],
        ["Carat-price correlation",f'{d["carat_price_pearson"]:.3f}',"Strong positive linear association"],
        ["Raw missing cells",str(d["raw_missing_cells"]),"No standard null-value imputation required"],
    ],[1.67*inch,1.65*inch,BODYW-3.32*inch])
    paragraph("<b>Unit of analysis:</b> one row describes one diamond. No timestamp supports chronological forecasting; quality grades are categories, not equal-distance numeric scores.")
    newpage()

    # 05 EDA
    heading("02.3", "What the exploratory plots reveal", "exploration")
    figure("01_data_exploration.png","Figure 1. Original visual analysis: price distribution, carat-price scatter, unadjusted cut medians, and cut-by-clarity sample coverage. All panels were generated using the project code.")
    paragraph(f"The histogram shows a strong right tail, with a cleaned mean of {money(d['price_mean'])} but a median of only {money(d['price_median'])}. A simple average would therefore exaggerate the price a typical diamond costs. The scatterplot shows a strong carat-price relationship (Pearson r = {d['carat_price_pearson']:.3f}), but diamonds at similar weights still occupy a broad price range. This spread is exactly why color and clarity may help.")
    paragraph("The cut-by-clarity count heatmap confirms that examples are not uniformly distributed across quality combinations. A model trained on common combinations may be less dependable for rare combinations; this motivates the later error analysis. These plots are descriptive rather than evidence of cause-and-effect.")
    newpage()

    # 06 EDA nuance
    heading("02.4", "A surprising result hiding in plain sight", "exploration")
    figure("02_carat_bands.png","Figure 2. Median listed price by increasing carat range. The increase is visibly nonlinear rather than a single fixed dollar increase per carat.")
    sub("Why 'Ideal' is not automatically the most expensive group")
    paragraph(f"When grouped only by cut, the cleaned dataset shows a median listed price of {money(eda['cut_median_price']['Ideal'])} for <i>Ideal</i> and {money(eda['cut_median_price']['Fair'])} for <i>Fair</i>. That sounds backward: surely the better cut should cost more. But the typical <i>Ideal</i> diamond weighs {eda['cut_median_carat']['Ideal']:.2f} carats, while the typical <i>Fair</i> diamond weighs {eda['cut_median_carat']['Fair']:.2f} carats. Comparing unadjusted group prices quietly mixes differences in size with differences in quality.")
    paragraph("This is a confounding problem: a raw relationship between cut and price is distorted by the distribution of carat. The model needs to consider features together, and the report should not declare that a lower cut grade makes diamonds more valuable based on a single bar chart. Similar limitations apply to interpreting fitted feature importance as a causal price premium.")
    sub("Practical observations from EDA")
    bullet("A fixed dollar error should be read differently for a $500 stone than for a $15,000 stone.")
    bullet("Carat creates a strong predictive baseline, but the vertical scatter suggests meaningful information in quality labels.")
    bullet("High-end stones are substantially less common; the largest errors may cluster at the top of the price distribution.")
    newpage()

    # 07 preprocessing
    heading("03", "Preprocessing and leakage prevention", "from raw data to reliable inputs")
    sub("3.1 Cleaning audit")
    tbl([
        ["STEP","NUMBER OF ROWS","WHY"],
        ["Original data",f'{d["raw_rows"]:,}',"Source CSV with ten columns"],
        ["Drop exact duplicates",f'-{d["exact_duplicates_removed"]:,}',"Avoid identical full records landing across train and test"],
        ["Drop invalid dimensions",f'-{d["invalid_geometry_rows_removed"]:,}',"At least one x/y/z value <= 0 or > 20 mm"],
        ["Final modeling set",f'{d["retained_rows"]:,}',"Complete features and positive physical dimensions"],
    ],[1.72*inch,1.5*inch,BODYW-3.22*inch])
    paragraph("There are no conventional missing cells in the raw CSV, so imputing blank values is unnecessary. However, a zero-length physical dimension cannot describe a real diamond; isolated entries above 20 mm also conflict with the scale of the other stone measurements and are treated as likely recording errors. The 20-mm rule is a documented quality-control heuristic, not a universal gemological law. Removing duplicate rows is conservative because identical measurements could represent different real stones; the effect is small (146 rows, below 0.3%).")
    sub("3.2 Encoding, scaling and target integrity")
    bullet("<b>Numeric:</b> carat, depth, table, x, y, and z remain numeric. StandardScaler is fitted for Ridge because regularization depends on predictor scale.")
    bullet("<b>Categorical:</b> cut, color, and clarity are one-hot encoded (no false assumption that grade labels are evenly spaced). Unknown categories are handled safely.")
    bullet("<b>Tree models:</b> Random Forest and Gradient Boosting use unscaled numeric inputs; splits are not sensitive to feature units.")
    bullet("<b>Target:</b> price is never included in the predictor matrix. No normalization of price is required for the reported dollar-denominated metrics.")
    sub("3.3 Split and pipeline discipline")
    paragraph(f"After cleaning, I use deterministic price-decile-stratified random splitting (seed {r['seed']}) to form <b>{r['split_counts']['train']:,} training</b>, <b>{r['split_counts']['validation']:,} validation</b>, and <b>{r['split_counts']['test']:,} test</b> rows. Target deciles guide representation across splits only; they are never used as an input feature. The preprocessing transformers live inside scikit-learn pipelines so they are fitted exclusively with training observations and not with the held-out test data (Pedregosa et al.).")
    callout("Key safeguard: no 'peek at the answer key.' I selected each configuration using validation MAE, then opened the test set exactly for final reporting.")
    newpage()

    # 08 methods
    heading("04", "Methods: four different guesses", "algorithms and rationale")
    sub("4.1 Median baseline - what learning must beat")
    paragraph("A DummyRegressor predicts the training median for every observation. It cannot learn relationships, but it gives the experiment an honest minimum standard. With heavily skewed prices, the median is also a defensible starting guess under absolute-error loss.")
    sub("4.2 Ridge Regression - a controlled, interpretable benchmark")
    paragraph("Ridge is regularized linear regression. It models price as a weighted sum of predictors and chooses coefficients by minimizing squared error plus an L2 penalty: <b>sum(y - Xb)^2 + alpha * sum(b^2)</b>. The penalty discourages unstable coefficients when variables overlap, as geometric dimensions do (Hoerl and Kennard). It is fast and useful as a benchmark, but it cannot directly represent complex interactions without additional feature engineering.")
    sub("4.3 Random Forest - many trees, one average")
    paragraph("Random Forest fits multiple decision trees on bootstrap samples, varies candidate features, and averages the trees' predictions. The ensemble naturally learns thresholds and interactions, such as the price implication of being both large and high clarity, without manually coding interaction terms. Averaging reduces variance compared with relying on one very deep tree (Breiman). The selected configuration uses <b>140 trees</b>, <b>85% of transformed features considered per split</b>, and <b>minimum leaf size 1</b>.")
    sub("4.4 Histogram Gradient Boosting - sequential correction")
    paragraph("Gradient boosting builds a succession of smaller trees, each addressing errors left by the preceding ensemble. Histogram binning accelerates splitting for larger tabular datasets. The chosen experiment uses <b>230 iterations</b>, <b>learning rate 0.075</b>, <b>31 maximum leaf nodes</b>, and <b>L2 regularization 0.2</b>. It was included as a second nonlinear model because it learns interactions in a different way from independent-tree bagging (Friedman).")
    sub("4.5 Why compare these algorithms?")
    tbl([
        ["MODEL","STRENGTH","POTENTIAL WEAKNESS"],
        ["Ridge","Fast, stable linear benchmark","Underfits nonlinear price patterns"],
        ["Random Forest","Flexible interactions, robust averaging","May struggle in sparse/extreme regions"],
        ["Gradient Boosting","Sequential nonlinear refinement","Sensitive to tuning; can focus on outliers"],
    ],[1.37*inch,2.46*inch,BODYW-3.83*inch])
    newpage()

    # 09 experimental design
    heading("05", "Experimental design", "measure first, celebrate later")
    sub("5.1 Validation-based model selection")
    paragraph("All methods use the same cleaned rows and the same train/validation/test partitions. I fit each candidate on the training set, compared validation MAE, selected one configuration per algorithm, then retrained each selected configuration using the combined 80% training-plus-validation partition. Only then did I calculate final metrics on the untouched 20% test partition. The overall winner is selected by <i>validation MAE</i>, not by whichever test metric happens to look nicest.")
    tbl([
        ["ALGORITHM","SETTINGS TRIED ON VALIDATION","OTHER FIXED SETTINGS"],
        ["Ridge Regression","alpha = 0.1 vs. 100","Standardized numbers + one-hot categories"],
        ["Random Forest","min_samples_leaf = 1 vs. 3","140 trees, max_features = 0.85"],
        ["Gradient Boosting","max_leaf_nodes = 15 vs. 31","230 iterations, learning_rate = 0.075, L2 = 0.2"],
    ],[1.42*inch,2.15*inch,BODYW-3.57*inch])
    sub("5.2 Evaluation metrics")
    paragraph("<b>MAE = mean(|actual - predicted|):</b> the main selection metric; interpretable as average dollars of error. <b>RMSE = sqrt(mean((actual - predicted)^2)):</b> more heavily penalizes a few very large mistakes. <b>Median absolute error:</b> the typical row's error, less influenced by extreme misses. <b>R-squared = 1 - SSE/SST:</b> variation explained relative to predicting the test-set mean; negative scores are possible for a poor baseline (Pedregosa et al.).")
    sub("5.3 Reproducibility and scope of the test")
    bullet("Deterministic random seed: <b>42</b>. There are no learned target statistics in the feature preprocessing.")
    bullet("Six candidate runs are compared using one validation partition (two choices each for Ridge, Forest, and Boosting). This is modest tuning, not a broad hyperparameter search.")
    bullet("Three selected algorithms, plus the baseline, are evaluated on the same final untouched test rows.")
    bullet("A separate carat-only boosting model provides an additional ablation; it is a diagnostic comparison, not a new hyperparameter selected on test.")
    paragraph("<b>Potential limitation:</b> random splitting measures interpolation to similar diamonds within this dataset. It does not prove performance on future dates or a different retailer. Repeated exact records were removed first to reduce an obvious source of optimistic matching. More extensive grouped and external validation would improve confidence.")
    newpage()

    # 10 results
    heading("06", "Results and model comparison", "the measured outcome")
    sub("6.1 Validation, before test evaluation")
    tbl([
        ["MODEL","SELECTED CONFIGURATION","VALIDATION MAE","VALIDATION R2"],
        ["Median Baseline","Median of training prices",money(vm["Median Baseline"]["mae"],2),f'{vm["Median Baseline"]["r2"]:.3f}'],
        ["Ridge Regression","alpha = 0.1",money(vm["Ridge Regression"]["mae"],2),f'{vm["Ridge Regression"]["r2"]:.3f}'],
        ["Random Forest","min_samples_leaf = 1",money(vm["Random Forest"]["mae"],2),f'{vm["Random Forest"]["r2"]:.3f}'],
        ["Gradient Boosting","max_leaf_nodes = 31",money(vm["Gradient Boosting"]["mae"],2),f'{vm["Gradient Boosting"]["r2"]:.3f}'],
    ],[1.54*inch,1.94*inch,1.2*inch,BODYW-4.68*inch])
    sub("6.2 Final held-out test: 10,755 previously unseen rows")
    tbl([
        ["MODEL","MAE ↓","RMSE ↓","MED. AE ↓","R2 ↑"],
        *[[nm,money(met["mae"],2),money(met["rmse"],2),money(met["median_ae"],2),f'{met["r2"]:.3f}']
          for nm,met in metrics.items()]
    ],[1.70*inch,1.17*inch,1.17*inch,1.11*inch,BODYW-5.15*inch])
    figure("03_model_comparison.png","Figure 3. Same held-out test set for every method. Lower MAE and higher R-squared are better.",width=BODYW)
    paragraph(f"<b>Result:</b> Forest wins with {money(rf['mae'],2)} test MAE - {gain:.1f}% below the baseline. Ridge scores {money(metrics['Ridge Regression']['mae'],2)} MAE. Boosting narrowly wins on RMSE ({money(gb['rmse'],2)} vs. {money(rf['rmse'],2)}), a useful metric tradeoff.")
    newpage()

    # 11 residual diagnostics
    heading("06.3", "What the winning model gets right - and wrong", "diagnostics")
    figure("04_predictions_and_residuals.png","Figure 4. Random Forest test predictions versus actual listed prices (left), and signed errors by actual price (right). For legibility, 3,000 reproducibly sampled test points are shown.")
    paragraph(f"The diagonal cloud confirms that Random Forest tracks many low- and mid-price diamonds closely. Its median absolute error is only {money(rf['median_ae'],2)}; its mean absolute error is larger at {money(rf['mae'],2)}, indicating a minority of difficult cases with larger mistakes. RMSE of {money(rf['rmse'],2)} exceeds MAE for the same reason: squaring the errors gives exceptional misses extra weight.")
    paragraph(f"Approximately {r['within_500_fraction']*100:.1f}% of held-out predictions are within $500 of the listed price and {r['within_1000_fraction']*100:.1f}% fall within $1,000. The 90th-percentile absolute error is {money(r['test_p90_absolute_error'],2)}, meaning roughly one in ten test predictions misses by more than that amount. Mean signed error is only {money(r['test_signed_error_mean'],2)}, but near-zero average bias <b>does not</b> imply tiny individual errors - underpredictions and overpredictions can cancel.")
    sub("Interpretation")
    bullet("The line of perfect prediction is a reference, not an evaluation model; scattered departures are prediction mistakes.")
    bullet("Higher-price observations show a wider vertical spread. An apparently excellent overall R-squared can conceal meaningful misses on these items.")
    bullet("The test-set results are real computed model outputs. No fit lines or model scores were drawn by hand.")
    newpage()

    # 12 errors per segment
    heading("06.4","Who pays the price for prediction mistakes?", "segment analysis")
    figure("05_segment_errors.png","Figure 5. Test-set mean absolute error by actual price and by carat band for the validation-selected Random Forest.")
    tbl([
        ["PRICE BAND","TEST N","MEAN ABSOLUTE ERROR"],
        *[[name,f'{r["price_group_n"][name]:,}',money(err,2)] for name,err in r["price_group_mae"].items()]
    ],[1.55*inch,1.25*inch,BODYW-2.8*inch])
    paragraph(f"The cheapest diamonds (listed at or below about $1,000) have test MAE of {money(r['price_group_mae']['$0-1k'],2)}, compared with {money(r['price_group_mae']['$10k+'],2)} for stones priced above $10,000. Similarly, the group with carat weight greater than 2 has MAE of {money(r['carat_group_mae']['2+'],2)} versus {money(r['carat_group_mae']['0-0.5'],2)} for stones up to 0.5 carat. These are <i>absolute dollar errors</i>, so large-price segments naturally have more room for expensive mistakes.")
    paragraph("These group comparisons are descriptive. The price bands are determined from actual test prices solely to analyze error <i>after</i> prediction, not to supply a feature to the model. More calibrated relative-error metrics and segment-specific uncertainty intervals would be useful follow-up analyses.")
    newpage()

    # 13 importance
    heading("06.5", "Which features actually influence predictions?", "model interpretation")
    figure("06_permutation_importance.png","Figure 6. Held-out permutation importance for the selected Random Forest. Each feature is shuffled three times in a reproducible 2,000-row test sample; bars show the increase in MAE, with error bars representing variability across shuffles.")
    paragraph(f"The most consequential shuffled features were <b>y</b> (width; approximately {money(r['permutation_importance']['y'])} higher MAE) and <b>carat</b> (approximately {money(r['permutation_importance']['carat'])} higher MAE), followed by clarity and color. This is more informative than simply counting how often a tree splits on a feature: each importance value reports actual deterioration in prediction quality when one test column is scrambled (\"Permutation Feature Importance\").")
    paragraph("Width outranking carat in this sample is interesting but <b>not proof that width causes diamond prices to rise more than carat does</b>. Weight, length, and width describe correlated aspects of stone size, so shuffling one of them can create unrealistic feature combinations. The importance reflects what this particular trained model relies on under the test distribution, not an economic law or an independent price premium.")
    sub("Unexpected but valuable observations")
    bullet("The selected Random Forest appears to rely more on size and clarity than on cut, despite cut being a familiar marketing term.")
    bullet("Low importance of depth and table does not prove those measurements are irrelevant to gem quality; their predictive signal may overlap other dimensions.")
    bullet("A different dataset, retailer, missing dimensions, or model family could produce a different ranking.")
    newpage()

    # 14 ablation and validity
    heading("06.6", "Ablation, limitations, and improvements", "beyond the leaderboard")
    sub("The carat-only sanity check")
    carat=r["carat_only_boosting_test"]
    tbl([
        ["MODEL / INPUTS","TEST MAE","TEST R2"],
        ["Carat-only Gradient Boosting",money(carat["mae"],2),f'{carat["r2"]:.3f}'],
        ["Full-feature Gradient Boosting",money(gb["mae"],2),f'{gb["r2"]:.3f}'],
        ["Full-feature Random Forest",money(rf["mae"],2),f'{rf["r2"]:.3f}'],
    ],[2.95*inch,1.55*inch,BODYW-4.5*inch])
    paragraph(f"A Gradient Boosting model trained on <i>carat alone</i> gets {money(carat['mae'],2)} MAE; with the complete nine-feature profile, Gradient Boosting drops to {money(gb['mae'],2)} MAE. This is a meaningful reduction, supporting the view that dimensions and quality attributes add important information beyond weight. The full Random Forest remains better on MAE. Because the carat-only ablation is a purposely restricted model, it tests information content, not a fair contest of all possible one-feature model settings.")
    sub("Threats to validity")
    bullet("<b>Selection history unknown:</b> the data do not describe when or where prices were collected. Generalization across retail markets or recent prices is not established.")
    bullet("<b>Unobserved quality factors:</b> certification, fluorescence, brand, condition, retailer margin, and regional demand are not present.")
    bullet("<b>Random split:</b> nearly identical but nonduplicate stones can occur in train and test, so performance on unfamiliar classes of stones may be worse.")
    bullet("<b>Limited tuning:</b> two candidate settings per model make the comparison understandable, not exhaustive.")
    bullet("<b>Cleaning assumptions:</b> removed bad-size rows and exact repeats may represent special cases; model behavior on them is not evaluated.")
    sub("Next experiments I would run")
    bullet("Try GroupKFold by rounded carat/quality combinations or evaluate on a separate retailer's dataset.")
    bullet("Compare log-price models and more formal, nested cross-validation; report confidence intervals on test MAE.")
    bullet("Construct price bands or prediction intervals so a high-dollar appraisal includes honest uncertainty.")
    newpage()

    # 15 conclusion/reflections
    heading("07", "Conclusion and personal reflection", "what this project taught me")
    sub("7.1 Research conclusion")
    paragraph(f"This project asked whether machine learning can predict a diamond's listed price from its measurable and graded attributes. On the held-out test set, Random Forest achieved {money(rf['mae'],2)} MAE and {rf['r2']:.3f} R-squared, beating both the median baseline and Ridge Regression. Gradient Boosting remained competitive and slightly improved RMSE. The data strongly support the claim that nonlinear, interacting predictors matter for price reconstruction; they do not support a claim of precise, universal appraisal.")
    paragraph(f"The error diagnostics temper the headline numbers: mistakes rise from {money(r['price_group_mae']['$0-1k'],2)} MAE for the lowest price group to {money(r['price_group_mae']['$10k+'],2)} for the highest, and the feature-importance analysis requires caution because diamond dimensions are correlated. A genuinely good report should show both strengths and uncomfortable edges of its model.")
    sub("7.2 What I learned")
    paragraph("I learned that machine learning is much more than importing a model and pressing <i>fit()</i>. Data cleaning changed which examples were defensible; splitting before fitting transforms prevented an unfair head start; and choosing MAE made the question meaningful in dollars. I also learned to ask why a chart looks odd instead of immediately announcing a discovery. The misleading cut-price medians were my favorite example of this lesson.")
    paragraph("I missed a few classes along the way, so I relied on the homework, documentation, and hands-on experiments to close the gaps. It turns out the homework was not just something to submit at 11:59 p.m. - it was where concepts like overfitting, evaluation metrics, and train/test leakage finally clicked. I started by trying to make the score look good; I finished by caring more about whether the experiment was fair.")
    sub("7.3 Final takeaway")
    callout("A model that predicts 98% of the observed variation still deserves tough questions. The most useful skill I practiced was learning to ask those questions with evidence.")
    paragraph("In future work, I would prioritize independent market data, repeated grouped validation, and uncertainty ranges before improving the third decimal place of R-squared. That would move this from a strong classroom experiment toward a more responsible decision-support tool.")
    newpage()

    # 16+ MLA references
    heading("08", "Works Cited", "mla style")
    refs=[
        'Breiman, Leo. "Random Forests." <i>Machine Learning</i>, vol. 45, 2001, pp. 5-32. <link href="https://doi.org/10.1023/A:1010933404324" color="#316B87">doi:10.1023/A:1010933404324</link>.',
        '"Diamonds." <i>ggplot2</i>, Posit Software, <link href="https://ggplot2.tidyverse.org/reference/diamonds.html" color="#316B87">ggplot2.tidyverse.org/reference/diamonds.html</link>. Accessed 16 Nov. 2026.',
        '"Diamonds." <i>plotnine</i>, <link href="https://plotnine.org/reference/diamonds.html" color="#316B87">plotnine.org/reference/diamonds.html</link>. Accessed 16 Nov. 2026.',
        'Friedman, Jerome H. "Greedy Function Approximation: A Gradient Boosting Machine." <i>The Annals of Statistics</i>, vol. 29, no. 5, 2001, pp. 1189-1232. <link href="https://doi.org/10.1214/aos/1013203451" color="#316B87">doi:10.1214/aos/1013203451</link>.',
        'Hoerl, Arthur E., and Robert W. Kennard. "Ridge Regression: Biased Estimation for Nonorthogonal Problems." <i>Technometrics</i>, vol. 12, no. 1, 1970, pp. 55-67. <link href="https://doi.org/10.1080/00401706.1970.10488634" color="#316B87">doi:10.1080/00401706.1970.10488634</link>.',
        'Pedregosa, Fabian, et al. "Scikit-learn: Machine Learning in Python." <i>Journal of Machine Learning Research</i>, vol. 12, 2011, pp. 2825-2830. <link href="https://jmlr.org/papers/v12/pedregosa11a.html" color="#316B87">jmlr.org/papers/v12/pedregosa11a.html</link>.',
        '"Permutation Feature Importance." <i>Scikit-learn</i>, <link href="https://scikit-learn.org/stable/modules/permutation_importance.html" color="#316B87">scikit-learn.org/stable/modules/permutation_importance.html</link>. Accessed 16 Nov. 2026.',
        'Zhang, Yanze, et al. "Robotic Video Alignment Using Pose-aware Vision Transformers." 2023. Instructor-provided sample project report, <i>example1.pdf</i>.',
    ]
    for ref in refs:
        story.append(P(ref,"ref"))
    story.append(Spacer(1,5))
    sub("Acknowledgements and transparent AI disclosure")
    paragraph("I acknowledge the creators of the <i>diamonds</i> dataset and the open-source Python/scikit-learn communities for making this study possible. I consulted the instructor-provided sample report by Zhang and collaborators as a reference for academic organization, experiments, and reflection; none of its research results, figures, or wording were reused. OpenAI ChatGPT (GPT-6) assisted with project planning, research organization, Python code scaffolding, visual presentation, and report drafting/editing. The reported measurements and charts were calculated by actually running the included code on the cited dataset. The student should read, verify, and personalize this report and be able to explain every methodological choice.")
    sub("Source code / public GitHub repository")
    if github.startswith("https://") or github.startswith("http://"):
        url=escape(github)
        paragraph(f'<b>Public GitHub:</b> <link href="{url}" color="#316B87">{url}</link>')
    else:
        paragraph('<b>Public GitHub:</b> <font color="#A44D34"><b>[ADD YOUR PUBLIC GITHUB REPOSITORY LINK BEFORE SUBMISSION]</b></font>')
    paragraph("Included deliverables: <b>run_project.py</b> (complete reproducible ML pipeline), <b>make_report.py</b> (editable report generator), <b>Sparkle_Tax_Notebook.ipynb</b> (guided notebook), <b>data/diamonds.csv</b>, <b>requirements.txt</b>, <b>README.md</b>, figures and CSV outputs. Run <b>python run_project.py</b> to reproduce the numbers. GitHub upload/publication requires your account and cannot be verified from this PDF alone.")
    story.append(P("END OF REPORT", "eyebrow"))

    reportdate="16 November 2026"
    doc.build(story,onFirstPage=lambda canvas,doc:cover_page(canvas,doc,name,course,reportdate),onLaterPages=normal_page)
    return path


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--name",default="[YOUR NAME]")
    parser.add_argument("--course",default="[COURSE / INSTRUCTOR]")
    parser.add_argument("--github",default="[ADD PUBLIC REPO URL]")
    parser.add_argument("--output",default=str(ROOT/"The_Sparkle_Tax_Final_Report.pdf"))
    a=parser.parse_args()
    result=build(a.name,a.course,a.github,Path(a.output))
    print("Created",result)
